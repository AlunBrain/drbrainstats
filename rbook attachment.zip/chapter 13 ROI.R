library(dplyr)
dual1$numb <- 1

respond <- as.data.frame(dual1 %>% group_by(respond)
                         %>% summarize(sum_count=sum(numb)))

#deciling
#length = 11 as we get 0%
quantile(dual1$presp, prob = seq(0, 1, length = 11), type = 5)


# keep count of the brackects
dual2 <- within(dual1, respdec <-ifelse(presp<=0.0081372069, 10, 
                                 ifelse(presp<=0.0163934513, 9,
                                 ifelse(presp<=0.0232703846, 8,
                                 ifelse(presp<=0.0362130473, 7,
                                 ifelse(presp<=0.0499063846, 6,
                                 ifelse(presp<=0.0771615967, 5,                                      
                                 ifelse(presp<=0.1094659613, 4,
                                 ifelse(presp<=0.1690506095, 3,
                                 ifelse(presp<=0.2640565227, 2,  1  )))))))))) 


respdec <- as.data.frame(dual2 %>% group_by(respdec)
                         %>% summarize(sum_count=sum(numb), sum_resp=sum(respond) ))

respdec

# deciling sold

#base figures
sold <- as.data.frame(dual2 %>% group_by(sold)
                         %>% summarize(sum_count=sum(numb)))


quantile(dual1$psold, prob = seq(0, 1, length = 11), type = 5)

# keep count of the brackects
dual3 <- within(dual2, solddec <-ifelse(psold<=0.0012823874, 10, 
                                 ifelse(psold<=0.0032262299, 9,
                                 ifelse(psold<=0.0060599803, 8,
                                 ifelse(psold<=0.0103808538, 7,
                                 ifelse(psold<=0.0195353575, 6,
                                 ifelse(psold<=0.0262047080, 5,                                      
                                 ifelse(psold<=0.0466504266, 4,
                                 ifelse(psold<=0.0800654271, 3,
                                 ifelse(psold<=0.1523710080, 2,  1  )))))))))) 

solddec <- as.data.frame(dual3 %>% group_by(solddec)
                         %>% summarize(sum_count=sum(numb), sum_sold=sum(sold) ))


#dual
dual_strategy <- as.data.frame(dual3 %>% group_by(respdec, solddec)
                        %>% summarize(sum_count=sum(numb), 
                                      sum_resp=sum(respond), sum_sold=sum(sold) ))

