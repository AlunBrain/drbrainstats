
#use an appropriate binning package

install.packages("woeBinning")
library(woeBinning)

# first get all of the column names
colname <- as.data.frame(colnames(build))

# goto Excel to concatenate lots of code

#areacode should be factor not numerical

build$areacode <- as.factor(build$areacode)


bmain_salary<-woe.binning(build, 'target', 'main_salary', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bsecond_salary<-woe.binning(build, 'target', 'second_salary', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bannual_bonus<-woe.binning(build, 'target', 'annual_bonus', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bloan_os<-woe.binning(build, 'target', 'loan_os', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bhouse_value_change<-woe.binning(build, 'target', 'house_value_change', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bbank_balance_main<-woe.binning(build, 'target', 'bank_balance_main', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bcredit_card_bal<-woe.binning(build, 'target', 'credit_card_bal', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bcar_loan<-woe.binning(build, 'target', 'car_loan', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bused_bank_overdraft<-woe.binning(build, 'target', 'used_bank_overdraft', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bowns_property<-woe.binning(build, 'target', 'owns_property', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bremarried<-woe.binning(build, 'target', 'remarried', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bdivorce<-woe.binning(build, 'target', 'divorce', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bage<-woe.binning(build, 'target', 'age', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bshares<-woe.binning(build, 'target', 'shares', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bsavings<-woe.binning(build, 'target', 'savings', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bchildren<-woe.binning(build, 'target', 'children', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bareacode<-woe.binning(build, 'target', 'areacode', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bcredit_card<-woe.binning(build, 'target', 'credit_card', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)


### next convert the above into data frames


dfmain_salary<- as.data.frame(bmain_salary)
dfsecond_salary<- as.data.frame(bsecond_salary)
dfannual_bonus<- as.data.frame(bannual_bonus)
dfloan_os<- as.data.frame(bloan_os)
dfhouse_value_change<- as.data.frame(bhouse_value_change)
dfbank_balance_main<- as.data.frame(bbank_balance_main)
dfcredit_card_bal<- as.data.frame(bcredit_card_bal)
dfcar_loan<- as.data.frame(bcar_loan)
dfused_bank_overdraft<- as.data.frame(bused_bank_overdraft)
dfowns_property<- as.data.frame(bowns_property)
dfremarried<- as.data.frame(bremarried)
dfdivorce<- as.data.frame(bdivorce)
dfage<- as.data.frame(bage)
dfshares<- as.data.frame(bshares)
dfsavings<- as.data.frame(bsavings)
dfchildren<- as.data.frame(bchildren)
dfareacode<- as.data.frame(bareacode)
dfcredit_card<- as.data.frame(bcredit_card)

# clean the data so that they can all be appended on top of each other
# first only select key columns

dfmain_salary1 <- select(dfmain_salary,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfsecond_salary1 <- select(dfsecond_salary,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfannual_bonus1 <- select(dfannual_bonus,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfloan_os1 <- select(dfloan_os,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfhouse_value_change1 <- select(dfhouse_value_change,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfbank_balance_main1 <- select(dfbank_balance_main,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfcredit_card_bal1 <- select(dfcredit_card_bal,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfcar_loan1 <- select(dfcar_loan,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfused_bank_overdraft1 <- select(dfused_bank_overdraft,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfowns_property1 <- select(dfowns_property,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfremarried1 <- select(dfremarried,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfdivorce1 <- select(dfdivorce,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfage1 <- select(dfage,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfshares1 <- select(dfshares,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfsavings1 <- select(dfsavings,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfchildren1 <- select(dfchildren,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)





#send add in which variable values refer to
dfmain_salary1$var1 <-'main_salary'
dfsecond_salary1$var1 <-'second_salary'
dfannual_bonus1$var1 <-'annual_bonus'
dfloan_os1$var1 <-'loan_os'
dfhouse_value_change1$var1 <-'house_value_change'
dfbank_balance_main1$var1 <-'bank_balance_main'
dfcredit_card_bal1$var1 <-'credit_card_bal'
dfcar_loan1$var1 <-'car_loan'
dfused_bank_overdraft1$var1 <-'used_bank_overdraft'
dfowns_property1$var1 <-'owns_property'
dfremarried1$var1 <-'remarried'
dfdivorce1$var1 <-'divorce'
dfage1$var1 <-'age'
dfshares1$var1 <-'shares'
dfsavings1$var1 <-'savings'
dfchildren1$var1 <-'children'


# areacode and credit card are character variables so does not contain cutpoints.final

dfareacode1 <- select(dfareacode,  woe, Group.1, Group.2,  iv.total.final, X1, X0)

dfcredit_card1 <- select(dfcredit_card,  woe, Group.1, Group.2,  iv.total.final, X1, X0)

# Create columns called cutpoints based on Group

dfareacode1$cutpoints.final<-dfareacode1$Group.1
dfareacode1$cutpoints.final..1. <-dfareacode1$Group.2


dfcredit_card1$cutpoints.final<-dfcredit_card1$Group.1
dfcredit_card1$cutpoints.final..1. <-dfcredit_card1$Group.2

# drop columns

dfareacode1 <- select(dfareacode1, -Group.1, -Group.2)
dfcredit_card1 <- select(dfcredit_card1, -Group.1, -Group.2)

# giving the data frames their variable names
dfareacode1$var1 <-'areacode'
dfcredit_card1$var1 <-'credit_card'

# concatenate

allwoe <- rbind(dfmain_salary1,
                dfsecond_salary1,
                dfannual_bonus1,
                dfloan_os1,
                dfhouse_value_change1,
                dfbank_balance_main1,
                dfcredit_card_bal1,
                dfcar_loan1 ,
                dfused_bank_overdraft1,
                dfowns_property1,
                dfremarried1,
                dfdivorce1,
                dfage1,
                dfshares1,
                dfsavings1,
                dfchildren1,
                dfareacode1,
                dfcredit_card1)

allwoe$total <- allwoe$X1 + allwoe$X0



# only keep variables that are predictive in the build data frame

# bin all of the variables
binningall <- woe.binning(build, 'target', build,
                       min.perc.total=0.05, min.perc.class=0.01,
                       stop.limit=0.1)


# Deploy the binning solution to the data frame
# (i.e. add binned variables and corresponding WOE variables)

df.results <- woe.binning.deploy(build, binningall, add.woe.or.dum.var='woe')

# (add binned variables with IV>=0.1 and corresponding dummy variables)
df.ivover <- woe.binning.deploy(build, binningall,  min.iv.total=0.1,add.woe.or.dum.var='dum')
