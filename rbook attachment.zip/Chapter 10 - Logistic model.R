
# full model

fullmod <- glm(target ~ factor(age.binned	) + factor(bank_balance_main.binned	) + factor(children.binned	) +
                   factor(credit_card.binned	) + factor(divorce.binned	) + factor(house_value_change.binned	) +
                   factor(loan_os.binned	) + factor(main_salary.binned) +	 factor(owns_property.binned	) +
                   factor(second_salary.binned	) + factor(used_bank_overdraft.binned	) ,
                    family=binomial, data=dfbuild1)

# backwards = step(fullmod,trace=0) would suppress step by step output.

backwards = step(fullmod) # Backwards selection is the default

summary(backwards)

formula(backwards)

# target ~ factor(age.binned) + factor(bank_balance_main.binned) + 
#  factor(children.binned) + factor(divorce.binned) + factor(house_value_change.binned) + 
#  factor(loan_os.binned) + factor(main_salary.binned) + factor(owns_property.binned) + 
#  factor(second_salary.binned) + factor(used_bank_overdraft.binned)

# to calculate our Gini and AUC

install.packages("ROCR", dependencies = TRUE)
library(ROCR)

logistmod <- glm( target ~ factor(age.binned) + factor(bank_balance_main.binned) + 
    factor(children.binned) + factor(divorce.binned) + factor(house_value_change.binned) + 
    factor(loan_os.binned) + factor(main_salary.binned) + factor(owns_property.binned) + 
    factor(second_salary.binned) + factor(used_bank_overdraft.binned), 
           family=binomial(link = logit), data=dfbuild1)

# to apply the predicted values

dfbuild1$prob<-predict(logistmod, newdata = dfbuild1, type = "response")

perfa <- performance(prediction(dfbuild1$prob, dfbuild1$target), measure = "auc")
auc <- perfa@y.values[[1]]  
	gini <- (2*auc)-1

	auc
	gini
