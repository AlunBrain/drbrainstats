install.packages("ROCR", dependencies = TRUE)
library(ROCR)
library(dplyr)

logistmod <- glm( target ~ factor(age.binned) + factor(bank_balance_main.binned) + 
                    factor(children.binned) + factor(divorce.binned) + factor(house_value_change.binned) + 
                    factor(loan_os.binned) + factor(main_salary.binned) + factor(owns_property.binned) + 
                    factor(second_salary.binned) + factor(used_bank_overdraft.binned), 
                  family=binomial(link = logit), data=dfbuild1)

# to apply the predicted values on the validation

dfvalid1$prob<-predict(logistmod, newdata = dfvalid1, type = "response")
perfa <- performance(prediction(dfvalid1$prob, dfvalid1$target), measure = "auc")
auc <- perfa@y.values[[1]]  
gini <- (2*auc)-1


aucx<-performance(prediction(dfvalid1$prob, dfvalid1$target), measure = "auc")@y.values[[1]] 
gini <- (2*aucx)-1

auc1
gini


# boot strapping validation

install.packages("boot")
library(boot)

giniboot <- function(dfvalid1, d) {
  E=dfvalid1[d,]
  fit = performance(prediction(E$prob, E$target), measure = "auc")@y.values[[1]] 
  return((2*fit)-1)
}


ginibootstrap<- boot(dfvalid1, giniboot, R=100)

quantile(ginibootstrap$t)




#correltaion

#aplly all woe bins to the data
corbuild <- woe.binning.deploy(build1, bin_all, add.woe.or.dum.var='woe')

# amend bank_balance_main woe values as you chnaged bins


##bank_balance_main.binned
dfbuild1$numb <-1
bank_bal <- as.data.frame(dfbuild1 %>% group_by(bank_balance_main.binned)
                          %>% summarize(sum_count=sum(numb), tot_tagret=sum(target) ))

# woe calcuated in Excel

corbuild <- within(corbuild,woe.bank_balance_main.binned <-ifelse(bank_balance_main<=450, 79, 
                                                           ifelse(bank_balance_main<=2700, 262,
                                                          ifelse(bank_balance_main>2700, -128,0))) )

corbuild1<- select(corbuild, woe.age.binned,        woe.bank_balance_main.binned,
                      woe.children.binned,           woe.divorce.binned, 
                      woe.house_value_change.binned, woe.loan_os.binned, 
                      woe.main_salary.binned,        woe.owns_property.binned,
                      woe.second_salary.binned,      woe.used_bank_overdraft.binned)


corres <- as.data.frame(cor(corbuild1, method = "pearson"))


#reversal cauality

rev1 <-  allwoe[which(allwoe$var1 %in% c('age',
                                       'children', 'divorce', 
                                       'house_value_change', 'loan_os', 
                                       'main_salary','owns_property',
                                       'second_salary','used_bank_overdraft')), ]


rev2 <- select(rev1, var1, total, X1,  cutpoints.final..1.)

# use the data frame bank_bal and rename columns

names(bank_bal) <- c("cutpoints.final..1.", "total", "X1")
bank_bal$var1 <- "bank_balance_main"

# append the data

rev3 <-rbind(rev2, bank_bal)

#only where there are values
rev4 <- rev3[which(rev3$total>0), ]






