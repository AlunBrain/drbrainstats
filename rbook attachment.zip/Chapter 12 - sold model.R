dmsetsold <- read.csv("C:/TEMP/dm book R/dmset.csv")  

## adding a column which has value 1
## add a new column called target based on sold

dmsetsold$numb <- 1
dmsetsold$target<-(dmset$sold)

## 70% of the sample size
samp_size <- floor(0.70 * nrow(dmsetsold))

## set the seed to make your partition reproducible
set.seed(1010)
valid_ind <- sample(seq_len(nrow(dmsetsold)), size = samp_size)

soldbuild <- dmsetsold[valid_ind, ]
soldvalid <- dmsetsold[-valid_ind, ]

## launch dplyr
library('dplyr')

## summarised statistics

soldbuild %>% summarize(total=sum(numb), sum_target=sum(target))
soldvalid %>% summarize(total=sum(numb), sum_target=sum(target))



### binning the variables  

#areacode should be factor not numerical

soldbuild$areacode <- as.factor(soldbuild$areacode)

library(woeBinning)

bmain_salary<-woe.binning(soldbuild, 'target', 'main_salary', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bsecond_salary<-woe.binning(soldbuild, 'target', 'second_salary', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bannual_bonus<-woe.binning(soldbuild, 'target', 'annual_bonus', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bloan_os<-woe.binning(soldbuild, 'target', 'loan_os', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bhouse_value_change<-woe.binning(soldbuild, 'target', 'house_value_change', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bbank_balance_main<-woe.binning(soldbuild, 'target', 'bank_balance_main', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bcredit_card_bal<-woe.binning(soldbuild, 'target', 'credit_card_bal', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bcar_loan<-woe.binning(soldbuild, 'target', 'car_loan', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bused_bank_overdraft<-woe.binning(soldbuild, 'target', 'used_bank_overdraft', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bowns_property<-woe.binning(soldbuild, 'target', 'owns_property', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bremarried<-woe.binning(soldbuild, 'target', 'remarried', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bdivorce<-woe.binning(soldbuild, 'target', 'divorce', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bage<-woe.binning(soldbuild, 'target', 'age', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bshares<-woe.binning(soldbuild, 'target', 'shares', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bsavings<-woe.binning(soldbuild, 'target', 'savings', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bchildren<-woe.binning(soldbuild, 'target', 'children', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bareacode<-woe.binning(soldbuild, 'target', 'areacode', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)
bcredit_card<-woe.binning(soldbuild, 'target', 'credit_card', min.perc.total=0.05, min.perc.class=0.01, stop.limit=0.1)


### next convert the above into data frames


dfmain_salary<- as.data.frame(bmain_salary)
dfsecond_salary<- as.data.frame(bsecond_salary)
dfannual_bonus<- as.data.frame(bannual_bonus)
dfloan_os<- as.data.frame(bloan_os)
dfhouse_value_change<- as.data.frame(bhouse_value_change)
dfbank_balance_main<- as.data.frame(bbank_balance_main)
dfcredit_card_bal<- as.data.frame(bcredit_card_bal)
dfcar_loan<- as.data.frame(bcar_loan)
dfused_bank_overdraft<- as.data.frame(bused_bank_overdraft)
dfowns_property<- as.data.frame(bowns_property)
dfremarried<- as.data.frame(bremarried)
dfdivorce<- as.data.frame(bdivorce)
dfage<- as.data.frame(bage)
dfshares<- as.data.frame(bshares)
dfsavings<- as.data.frame(bsavings)
dfchildren<- as.data.frame(bchildren)
dfareacode<- as.data.frame(bareacode)
dfcredit_card<- as.data.frame(bcredit_card)

# clean the data so that they can all be appended on top of each other
# first only select key columns

dfmain_salary1 <- select(dfmain_salary,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfsecond_salary1 <- select(dfsecond_salary,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfannual_bonus1 <- select(dfannual_bonus,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfloan_os1 <- select(dfloan_os,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfhouse_value_change1 <- select(dfhouse_value_change,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfbank_balance_main1 <- select(dfbank_balance_main,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfcredit_card_bal1 <- select(dfcredit_card_bal,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfcar_loan1 <- select(dfcar_loan,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfused_bank_overdraft1 <- select(dfused_bank_overdraft,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfowns_property1 <- select(dfowns_property,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfremarried1 <- select(dfremarried,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfdivorce1 <- select(dfdivorce,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfage1 <- select(dfage,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfshares1 <- select(dfshares,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfsavings1 <- select(dfsavings,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)
dfchildren1 <- select(dfchildren,  woe, cutpoints.final, cutpoints.final..1., iv.total.final, X1, X0)





#add in which variable values refer to
dfmain_salary1$var1 <-'main_salary'
dfsecond_salary1$var1 <-'second_salary'
dfannual_bonus1$var1 <-'annual_bonus'
dfloan_os1$var1 <-'loan_os'
dfhouse_value_change1$var1 <-'house_value_change'
dfbank_balance_main1$var1 <-'bank_balance_main'
dfcredit_card_bal1$var1 <-'credit_card_bal'
dfcar_loan1$var1 <-'car_loan'
dfused_bank_overdraft1$var1 <-'used_bank_overdraft'
dfowns_property1$var1 <-'owns_property'
dfremarried1$var1 <-'remarried'
dfdivorce1$var1 <-'divorce'
dfage1$var1 <-'age'
dfshares1$var1 <-'shares'
dfsavings1$var1 <-'savings'
dfchildren1$var1 <-'children'


# areacode and credit card are character variables so does not contain cutpoints.final

dfareacode1 <- select(dfareacode,  woe, Group.1, Group.2,  iv.total.final, X1, X0)
dfcredit_card1 <- select(dfcredit_card,  woe, Group.1, Group.2,  iv.total.final, X1, X0)


#rename columns
dfareacode1 <- rename(dfareacode1, cutpoints.final=Group.1, cutpoints.final..1.=Group.2)
dfcredit_card1 <- rename(dfcredit_card1, cutpoints.final=Group.1, cutpoints.final..1.=Group.2)



# giving the data frames their variable names
dfareacode1$var1 <-'areacode'
dfcredit_card1$var1 <-'credit_card'

# concatenate

allwoe <- rbind(dfmain_salary1,
                dfsecond_salary1,
                dfannual_bonus1,
                dfloan_os1,
                dfhouse_value_change1,
                dfbank_balance_main1,
                dfcredit_card_bal1,
                dfcar_loan1 ,
                dfused_bank_overdraft1,
                dfowns_property1,
                dfremarried1,
                dfdivorce1,
                dfage1,
                dfshares1,
                dfsavings1,
                dfchildren1,
                dfareacode1,
                dfcredit_card1)

allwoe$total <- allwoe$X1 + allwoe$X0

# allwoe  exported to Excel 

# final bins 
# only keep variables interested in

soldbuild1 <- select(soldbuild, id, target,age, bank_balance_main, children,
                 credit_card, divorce,    house_value_change, loan_os,
                 main_salary, owns_property, second_salary,  used_bank_overdraft)

#  bin all of the variables
bin_all <- woe.binning(soldbuild1, 'target', soldbuild1,
                       min.perc.total=0.05, min.perc.class=0.01,
                       stop.limit=0.1)


dfsoldbuild <- woe.binning.deploy(soldbuild1, bin_all)

# remove loan_os
dfsoldbuild <- select (dfsoldbuild, -loan_os.binned)

#create loan_os bins

dfsoldbuild1 <- within(dfsoldbuild,loan_os.binned <-ifelse(loan_os<=-200, "-Inf, -200", 
                                                 ifelse(loan_os<=-4, "-200 to -4",
                                               ifelse(loan_os>-4, "-4, Inf","missing"))) )




#  repeat for validation


soldvalid1 <- select(soldvalid, id, target,age, bank_balance_main, children,
                     credit_card, divorce,    house_value_change, loan_os,
                     main_salary, owns_property, second_salary,  used_bank_overdraft)


dfsoldvalid <- woe.binning.deploy(soldvalid1, bin_all)

# remove loan_os
dfsoldvalid <- select (dfsoldvalid, -loan_os.binned)

#create loan_os bins

dfsoldvalid1 <- within(dfsoldvalid,loan_os.binned <-ifelse(loan_os<=-200, "-Inf, -200", 
                                                     ifelse(loan_os<=-4, "-200 to -4",
                                                     ifelse(loan_os>-4, "-4, Inf","missing"))) )


# model build


fullmod <- glm(target ~ factor(age.binned	) + factor(bank_balance_main.binned	) 
                   + factor(children.binned	) +   factor(credit_card.binned	) + 
                   factor(divorce.binned	) + factor(house_value_change.binned	) +
                 factor(loan_os.binned	) + factor(main_salary.binned) +	 
                 factor(owns_property.binned	) +  factor(second_salary.binned	) + 
                 factor(used_bank_overdraft.binned	) ,
                         family=binomial, data=dfsoldbuild1)

backwards = step(fullmod) # Backwards selection is the default

summary(backwards)

formula(backwards)


# to calculate our Gini and AUC

library(ROCR)

soldmod <- glm( target ~ factor(age.binned) + factor(bank_balance_main.binned) + 
                      factor(children.binned) + factor(divorce.binned) + 
                     factor(house_value_change.binned) +  factor(loan_os.binned) + 
                    factor(main_salary.binned) + factor(owns_property.binned) + 
                    factor(second_salary.binned) + factor(used_bank_overdraft.binned), 
                      family=binomial(link = logit), data=dfsoldbuild1)

# to apply the predicted values

dfsoldbuild1$prob<-predict(soldmod, newdata = dfsoldbuild1, type = "response")

perfa <- performance(prediction(dfsoldbuild1$prob, dfsoldbuild1$target), measure = "auc")
auc <- perfa@y.values[[1]]  
gini <- (2*auc)-1


# to apply the predicted values on the validation

dfsoldvalid1$prob<-predict(soldmod, newdata = dfsoldvalid1, type = "response")
perfa <- performance(prediction(dfsoldvalid1$prob, dfsoldvalid1$target), measure = "auc")
auca <- perfa@y.values[[1]]  
ginia <- (2*auca)-1

gini
ginia



library(boot)

giniboot <- function(dfsoldvalid1, d) {
  E=dfsoldvalid1[d,]
  fit = performance(prediction(E$prob, E$target), measure = "auc")@y.values[[1]] 
  return((2*fit)-1)
}

ginibootstrap<- boot(dfsoldvalid1, giniboot, R=200)
quantile(ginibootstrap$t)


# correltaion


#correltaion

#aplly all woe bins to the data

corsoldbuild <- woe.binning.deploy(soldbuild1, bin_all, add.woe.or.dum.var='woe')

# amend loan_os woe values as you changed bins
dfsoldbuild1$numb <-1
loan_os <- as.data.frame(dfsoldbuild1 %>% group_by(loan_os.binned)
                          %>% summarize(sum_count=sum(numb), tot_tagret=sum(target) ))

# woe calcuated in Excel

corsoldbuild <- within(corsoldbuild,woe.loan_os.binned <-ifelse(loan_os<=-200, 59.8, 
                                                         ifelse(loan_os<=-4, 0,
                                                         ifelse(loan_os>-4, -97.8,0))) )

corsoldbuild1<- select(corsoldbuild, woe.age.binned,        woe.bank_balance_main.binned,
                   woe.children.binned,           woe.divorce.binned, 
                   woe.house_value_change.binned, woe.loan_os.binned, 
                   woe.main_salary.binned,        woe.owns_property.binned,
                   woe.second_salary.binned,      woe.used_bank_overdraft.binned)


corres <- as.data.frame(cor(corsoldbuild1, method = "pearson"))

#  reversal


#reversal cauality - excluding loan_os

rev1 <-  allwoe[which(allwoe$var1 %in% c('age', 'bank_balance_main',
                                         'children', 'divorce', 
                                         'house_value_change',  
                                         'main_salary','owns_property',
                                         'second_salary','used_bank_overdraft')), ]


rev2 <- select(rev1, var1, total, X1,  cutpoints.final..1.)

# use the data frame loan_os and rename columns

names(loan_os) <- c("cutpoints.final..1.", "total", "X1")
loan_os$var1 <- "loan_os"

# append the data

rev3 <-rbind(rev2, loan_os)

#only where there are values
rev4 <- rev3[which(rev3$total>0), ]


# contribuition

contrib <- read.csv("C:/TEMP/dm book R/contribution.csv")  

# first sumprob
sumprob <- as.data.frame(contrib %>% group_by(var1)
                         %>% summarize(sumprob=sum(pop_estimate) ))
# merge sumprob to contrib

contrib1 <- merge(x=contrib,y=sumprob,by="var1", all=TRUE)
# add on a new column called scor1

contrib1$scor1 <-abs((contrib1$estimate - contrib1$sumprob) * contrib$Population)

# sum up scor1 by var1
sumscor1 <- as.data.frame(contrib1 %>% group_by(var1)
                         %>% summarize(sumscor=sum(scor1) ))

sum(sumscor1$sumscor)
sumscor1$perc <- sumscor1$sumscor / sum(sumscor1$sumscor)



# combining reponse and sold models together

#repsonse models

respbuild <- select(dfbuild1, id, target, prob)
respvalid <- select(dfvalid1, id, target, prob)
allresp <- rbind(respbuild, respvalid)
allresp <- rename(allresp, presp=prob, respond=target)

#sold model
soldb <- select(dfsoldbuild1, id, target, prob)
soldv <- select(dfsoldvalid1, id, target, prob)
allsold <- rbind(soldb, soldv)
allsold <- rename(allsold, psold=prob, sold=target)


# sort and merge

allresp <- allresp[order(allresp$id), ]
allsold <- allsold[order(allsold$id), ]

dual1 <- merge(x=allresp,y=allsold,by="id", all=TRUE)





