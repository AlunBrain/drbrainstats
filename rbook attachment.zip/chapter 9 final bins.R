#  only use variables that you want to put forward in the model
library(dplyr)
library(woeBinning)

build1 <- select(build, id, target,age, bank_balance_main, children,
                 credit_card, divorce,    house_value_change, loan_os,
                 main_salary, owns_property, second_salary,  used_bank_overdraft)

#  bin all of the variables
bin_all <- woe.binning(build1, 'target', build1,
                          min.perc.total=0.05, min.perc.class=0.01,
                          stop.limit=0.1)
# get the package to create a data frae with the binned variables
# use thi if you wan the WoE value.. which we do not
#dfbuild <- woe.binning.deploy(build1, bin_all, add.woe.or.dum.var='woe')

dfbuild <- woe.binning.deploy(build1, bin_all)

# remove main bank balance
dfbuild <- select (dfbuild, -bank_balance_main.binned)

#create main bank balance bins

dfbuild1 <- within(dfbuild,bank_balance_main.binned <-ifelse(bank_balance_main<=450, "-Inf, 450", 
                                            ifelse(bank_balance_main<=2700, "450 to 2700",
                                                   ifelse(bank_balance_main>2700, "2700, Inf","missing"))) )


#  repeat for validation


valid1 <- select(valid, id, target,age, bank_balance_main, children,
                 credit_card, divorce,    house_value_change, loan_os,
                 main_salary, owns_property, second_salary,  used_bank_overdraft)

dfvalid <- woe.binning.deploy(valid1, bin_all)

# remove main bank balance
dfvalid <- select (dfvalid, -bank_balance_main.binned)

#create main bank balance bins

dfvalid1 <- within(dfvalid,bank_balance_main.binned <-ifelse(bank_balance_main<=450, "-Inf, 450", 
                                                      ifelse(bank_balance_main<=2700, "450 to 2700",
                                                      ifelse(bank_balance_main>2700, "2700, Inf","missing"))) )

