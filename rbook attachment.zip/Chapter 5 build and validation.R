dmset <- read.csv("C:/TEMP/dm book R/dmset.csv")  

## adding a column which has value 1
## add a new column called target based on respone

dmset$numb <- 1
dmset$target<-(dmset$response)

## 70% of the sample size
samp_size <- floor(0.70 * nrow(dmset))

## set the seed to make your partition reproducible
set.seed(103)
valid_ind <- sample(seq_len(nrow(dmset)), size = samp_size)

build <- dmset[valid_ind, ]
valid <- dmset[-valid_ind, ]

## incase you have not installed dplyr

install.packages("dplyr")
library('dplyr')

## summarised statistics

build %>% summarize(total=sum(numb), sum_target=sum(target))
valid %>% summarize(total=sum(numb), sum_target=sum(target))